from aiogram import Bot, Dispatcher, types
from aiogram.types import WebAppInfo, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils import executor
from dotenv import load_dotenv
import os

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
WEBAPP_URL = os.getenv("WEBAPP_URL")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def start_handler(message: types.Message):
    keyboard = InlineKeyboardMarkup().add(
        InlineKeyboardButton(
            text="🧮 Open BTC Calculator",
            web_app=WebAppInfo(url=WEBAPP_URL)
        )
    )
    await message.answer("Click the button below to open the BTC simulator:", reply_markup=keyboard)

@dp.message_handler(content_types=types.ContentType.WEB_APP_DATA)
async def on_webapp_data(message: types.Message):
    await message.answer(f"📩 Data received from WebApp:\n\n{message.web_app_data.data}")

if __name__ == '__main__':
    executor.start_polling(dp)
